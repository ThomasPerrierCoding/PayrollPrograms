public class OutOfRangePricePerPieceException extends Exception implements IPayroll {
    public  OutOfRangePricePerPieceException(){
        super("Pieceworker Price Per Piece Must Be Between " + MINPPP + " and " + MAXPPP);
    }
}
