import java.util.Scanner;
import javax.swing.JOptionPane;

public class Payroll03
{
    public static void main(String[] args)
    {
        Scanner userInput = new Scanner(System.in);
        String empFirstName = "";
        String empMi = "";
        String empLastName = "";
        String inputStr="";
        String outputStr="";
        String empNumber = "";
        byte empAge = 0;
        boolean empIsUnion = false;
        double empHoursWorked = 0.0;
        double empHourlyRate = 0.0;
        double empGrossPay = 0.0;

        empFirstName=JOptionPane.showInputDialog("Input First Name");
        empMi=JOptionPane.showInputDialog("Input Middle Initial");
        empLastName=JOptionPane.showInputDialog("Input Last Name");

        inputStr=JOptionPane.showInputDialog("Input Age");
        empAge=Byte.parseByte(inputStr);

        inputStr=JOptionPane.showInputDialog("Input Union Status");
        empIsUnion=Boolean.parseBoolean(inputStr);

        empNumber=JOptionPane.showInputDialog("Input Employee Number");

        inputStr=JOptionPane.showInputDialog("Input Hours Worked");
        empHoursWorked=Double.parseDouble(inputStr);

        inputStr=JOptionPane.showInputDialog("Input Hourly Pay");
        empHourlyRate=Double.parseDouble(inputStr);

        empGrossPay=empHoursWorked*empHourlyRate;

        outputStr="Employee First Name: " + empFirstName + "\nEmployee Middle Initial: "+empMi+"\nEmployee Last Name:" +
                " "+empLastName+"\nEmployee Age: "+empAge+"\nEmployee Union Status: "+empIsUnion+"\nEmployee Hours " +
                "Worked: "+empHoursWorked+"\nEmployee Hourly Pay: "+empHourlyRate+"\nEmployee Gross Pay: "+empGrossPay;
        /*
        outputStr="Employee First Name: " + empFirstName";
        outputStr+= "\nEmployee Middle Initial: "+empMi;
        outputStr+= "\nEmployee Last Name: "+empLastName;
        outputStr+= "\nEmployee Age: "+empAge;
        outputStr+= "\nEmployee Union Status: "+empIsUnion;
        outputStr+= "\nEmployee Number: "+empNumber;
        outputStr+= "\nEmployee Hours Worked: "+empHoursWorked;
        outputStr+= "\nEmployee Hourly Pay: "+empHourlyRate;
        outputStr+= "\nEmployee Gross Pay: "+empGrossPay;
         */

        System.out.println(outputStr);


    }
}
