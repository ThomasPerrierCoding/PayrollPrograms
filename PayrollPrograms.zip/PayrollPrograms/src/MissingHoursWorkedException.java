public class MissingHoursWorkedException extends Exception {
    public MissingHoursWorkedException(){
        super("No Hours Worked Provided!");
    }
}
