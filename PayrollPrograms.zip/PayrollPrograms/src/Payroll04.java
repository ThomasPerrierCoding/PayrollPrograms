import java.util.Scanner;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Payroll04
{
    // Constants
    private static final double MAXNONOT = 40.0;
    private static final double OTRATE = 40.0;
    private static final byte MINAGE = 18;
    private static final byte MAXAGE = 75;
    private static final double MINHOURS = 0.0;
    private static final double MAXHOURS = 84.0;
    private static final double MINRATE = 0.0;
    private static final double MAXRATE = 100.0;
    private static final int TOTEMPS = 5;

    // Global Variables
    private static double totGrossPay=0.0;
    private static DecimalFormat pattern1 = new DecimalFormat("$###,###,##0.00");
    private static DecimalFormat pattern2 = new DecimalFormat("###,###,##0.00");

    public static void main(String[] args)
    {
        // Local Variables
        String empFirstName = "";
        String empMi = "";
        String empLastName = "";
        String empNumber = "";
        byte empAge = 0;
        boolean empIsUnion = false;
        double empHoursWorked = 0.0;
        double empHourlyRate = 0.0;
        double empGrossPay = 0.0;

        // For loop that asks for input for employee information. Loops a total amount of times equal to the value set for the global variable of TOTEMPS
        for(int i = 0;i <= TOTEMPS;++i)
        {
            empFirstName = inputEmpFirstName();
            empMi = inputEmpMiddleInit();
            empLastName = inputEmpLastName();
            empAge = inputEmpAge();
            empIsUnion = inputEmpUnionStatus();
            empNumber = inputEmpNumber();
            empHoursWorked = inputEmpHoursWorked();
            empHourlyRate = inputEmpHourlyRate();
            empGrossPay = calcGrossPay(empHoursWorked,empHourlyRate);
            displayAll(empFirstName,empMi,empLastName,empAge,empIsUnion,empNumber,empHoursWorked,empHourlyRate,empGrossPay);
        }
    }

    // Method used for asking the user to input information for employee
    public static String  inputEmpFirstName()
    {
        String fn = "";

        do{
            fn = JOptionPane.showInputDialog("Input First Name");
            fn = fn.trim();
        } while(fn.equals(""));

        return fn;
    }

    // Method used for asking the user to input information for employee
    public static String inputEmpMiddleInit()
    {
        String mi = "";

        do{
            mi = JOptionPane.showInputDialog("Input Middle Initial");
            mi = mi.trim();
        } while(mi.equals(""));

        return mi;
    }

    // Method used for asking the user to input information for employee
    public static String inputEmpLastName()
    {
        String ln = "";

        do{
            ln= JOptionPane.showInputDialog("Input Last Name");
            ln = ln.trim();
        } while(ln.equals(""));

        return ln;
    }

    // Method used for asking the user to input information for employee
    public static byte inputEmpAge()
    {
        String inputStr=JOptionPane.showInputDialog("Input Age Between "+MINAGE + " and " + MAXAGE);
        byte age = Byte.parseByte(inputStr);

        while (age <MINAGE  || age > MAXAGE)
        {
           inputStr=JOptionPane.showInputDialog("Input Age Between "+MINAGE + " and " + MAXAGE);
            age = Byte.parseByte(inputStr);
        }

        return age;
    }

    // Method used for asking the user to input information for employee
    public static boolean inputEmpUnionStatus()
    {
        String inputStr="";

        do
        {
            inputStr=JOptionPane.showInputDialog("Input Union Status (TRUE or FALSE)");
            inputStr = inputStr.trim();
        } while ((!inputStr.equals("true")) && !inputStr.equals("false"));

        boolean us=Boolean.parseBoolean(inputStr);

        return us;
    }

    // Method used for asking the user to input information for employee
    public static String inputEmpNumber()
    {
        String num = "";
        boolean match = false;

        do{
            num = JOptionPane.showInputDialog("Input Employee Number");
            num =num.trim();
            match = num.matches("^[0-9]{5}$");
        } while(num.equals("") || (!match));

        return num;
    }

    // Method used for asking the user to input information for the employee's number of hours worked
    public static double inputEmpHoursWorked()
    {
        double hw = 0.0;
        String inputStr = JOptionPane.showInputDialog("Input Hours Worked Between " + MINHOURS + " and " + MAXHOURS);
        hw = Double.parseDouble(inputStr);

        while (hw <MINHOURS || hw > MAXHOURS)
        {
            inputStr = JOptionPane.showInputDialog("Input Hours Worked Between " + MINHOURS + " and " + MAXHOURS);
            hw = Double.parseDouble(inputStr);
        }

        return hw;
    }

    // Method used for asking the user to input information for the employee's hourly rate
    public static double inputEmpHourlyRate()
    {
        double hr = 0.0;
        String inputStr = JOptionPane.showInputDialog("Input Hourly Rate Between " + MINRATE+ " and " + MAXRATE);
        hr = Double.parseDouble(inputStr);

        while (hr <MINHOURS || hr > MAXHOURS)
        {
            inputStr = JOptionPane.showInputDialog("Input Hourly Rate Between " + MINRATE+ " and " + MAXRATE);
            hr = Double.parseDouble(inputStr);
        }

        return hr;
    }

    // Method used for calculating the gross pay of the employee
    public static double calcGrossPay(double hoursWorked, double hourlyRate)
    {
        double gp = 0.0;
        if(hoursWorked<=MAXNONOT)
        {
            gp = hoursWorked * hourlyRate;
        }
        else
        {
            gp = ((MAXNONOT * hourlyRate) + (hoursWorked - MAXNONOT) * hourlyRate * OTRATE);
        }

        return gp;
    }

    // Method used for displaying all the information the user inputted for the employee
    public static void displayAll(String fn, String mi, String ln, byte age, boolean us, String num, double hw, double hr, double gp)
    {
        String outputStr="Employee First Name: " + fn + "\nEmployee Middle Initial: "+mi+"\nEmployee Last Name:" +
                " "+ln+"\nEmployee Age: "+age+"\nEmployee Union Status: "+us+"\nEmployee Hours " +
                "Worked: "+pattern2.format(hw)+"\nEmployee Hourly Pay: "+pattern1.format(hr)+"\nEmployee Gross Pay: "+pattern1.format(gp);
        JOptionPane.showMessageDialog(null, outputStr);

    }
}
