public class MissingSalaryException extends Exception implements IPayroll {
    public MissingSalaryException(){
        super("No Salary Provided!");
    }
}
