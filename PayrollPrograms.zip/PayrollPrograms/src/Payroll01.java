public class Payroll01
{
    // This is an example of a single line comment
    /* This is..
     ..an example..
     ..of a..
     ..multi-line comment*/
    /**
     * This is an example of a doc comment
     */
    public static void main(String[] args) // Can be done by typing psv and hitting tab

    {
        String empFirstName = "Edward";
        String empLastName="Elrich";
        String empNumber="123456";
        char empMi = 'D';
        byte empAge=19;
        boolean empIsUnion=false;
        double empHoursWorked=40.0;
        double empHourlyRate=10.0;
        double empGrossPay=0.0;

        empGrossPay = empHoursWorked * empHourlyRate;

        System.out.println("Emp First Name: " +empFirstName);
        System.out.println("Emp Middle Init : " +empMi);
        System.out.println("Emp  Last Name: " +empLastName);
        System.out.println("Emp Age : " +empAge);
        System.out.println("Emp  Union Status: " +empIsUnion);
        System.out.println("Emp Number : " +empNumber);
        System.out.println("Emp Hours Worked : " +empHoursWorked);
        System.out.println("Emp  Hourly Rate: " +empHourlyRate);
        System.out.println("Emp Gross Pay : " +empGrossPay);
}
}
