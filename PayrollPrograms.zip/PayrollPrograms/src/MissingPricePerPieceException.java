public class MissingPricePerPieceException extends Exception implements IPayroll {
    public MissingPricePerPieceException(){
        super("No Pieceworker Price Per Piece Provided!");
    }
}
