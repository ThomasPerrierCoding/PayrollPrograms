public class MissingLastNameException extends Exception {
    public MissingLastNameException(){
        super("No Last Name Provided!");
    }
}
