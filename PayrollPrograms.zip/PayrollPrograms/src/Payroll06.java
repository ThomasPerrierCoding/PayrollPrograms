public abstract class Payroll06
    implements IPayroll{ // Implements the constants located within the IPayroll interface
    //  Variables
    private String firstName;
    private String lastName;
    private String ssn;

    // No-Arg Constructor
    public Payroll06() {
        firstName = DEFFIRSTNAME;
        lastName = DEFLASTNAME;
        ssn = DEFSSN;
    }

    // Full-Arg Constructor
    public Payroll06(String fn, String ln, String ssn) {
        setFirstName(fn);
        setLastName(ln);
        setSsn(ssn);
    }

    // Getter for the firstName variable
    public String getFirstName() {
        return firstName;
    }
    // Setter for the firstName variable
    public void setFirstName(String fn) {
        this.firstName = (fn.equals("")
                                                ? DEFFIRSTNAME
                                                : fn);
    }

    // Getter for the lastName variable
    public String getLastName() {
        return lastName;
    }
    // Setter for the lastName variable
    public void setLastName(String ln) {
        this.lastName = (ln.equals("")
                                            ? DEFLASTNAME
                                            : ln);
    }

    // Getter for the ssn variable
    public String getSsn() {
        return ssn;
    }
    // Setter for the ssn variable
    public void setSsn(String ssn) {
        this.ssn = (ssn.equals("")
                                    ? DEFSSN
                                    : ssn);
    }

    public String toString(){
        return String.format("%s %s\nSSN: \t%s", getFirstName(), getLastName(), getSsn());
    }

    public abstract double earnings();
}
