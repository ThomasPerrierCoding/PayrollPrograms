public class MissingSalesException extends Exception{
    public MissingSalesException(){
        super("No Sales Provided!");
    }
}
