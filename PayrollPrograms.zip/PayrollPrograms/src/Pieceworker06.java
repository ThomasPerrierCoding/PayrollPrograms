public class Pieceworker06 extends Payroll06
                                                    implements IPayroll { // Implements the constants located within the IPayroll interface and extends the information found in the Payroll06 Class

    public int nop;     //  Number of pieces made
    public double ppp;      //  Price per piece made

    //  No-Arg Constructor
    public Pieceworker06(){
        super();
        this.nop = DEFNOP;
        this.ppp = DEFPPP;
    }

    //  Full-Arg Constructor
    public Pieceworker06(String fn, String ln, String ssn, int nop, double ppp){
        super(fn, ln, ssn);
        setNop(nop);
        setPpp(ppp);
    }

    // Getter for the nop variable
    public double getNop() {
        return nop;
    }
    // Setter for the nop variable
    public void setNop(int nop) {
        this.nop = ((nop >= MINNOP) && (nop <= MAXNOP)
                              ? nop : DEFNOP);
    }

    // Getter for the ppp variable
    public double getPpp() {
        return ppp;
    }
    // Setter for the ppp variable
    public void setPpp(double ppp) {
        this.ppp = ((ppp >= MINPPP) && (ppp <= MAXPPP)
                              ? ppp : DEFPPP);
    }

    //  Fills the output variable with the information for a pieceworker
    public String toString(){
        String outputStr = "";

        outputStr += "Pieceworker Payroll Object:";
        outputStr += "\nEmployee Name:\t\t\t\t" + getFirstName() +
                " " + getLastName();
        outputStr += "\nSOC Sec Num:\t\t\t\t" + getSsn();
        outputStr += "\nNumber of Pieces:\t\t" + getNop();
        outputStr += "\nPrice Per Piece:\t\t" + getPpp();
        outputStr += "\nEarnings:\t\t" + earnings();

        return outputStr;
    }

    //  Gets and returns the earnings for a pieceworker
    @Override
    public double earnings() {
        return getNop() * getPpp();
    }
}
