public class Salaried06 extends Payroll06
                                            implements IPayroll { // Implements the constants located within the IPayroll interface and extends the information found in the Payroll06 Class
    //  Variables
    private double rate;        //  Salary amount

    //  No-Arg Constructor
    public Salaried06(){
        super();
        this.rate = DEFSRATE;
    }

    //  Full-Arg Constructor
    public Salaried06(String fn, String ln, String ssn, double r){
        super(fn, ln, ssn);
        setRate(r);
    }

    // Getter for the rate variable
    public double getRate() {
        return rate;
    }
    //Setter for the rate variable
    public void setRate(double rate) {
        this.rate = ((rate >= MINSRATE) && (rate <= MAXSRATE)
                                ? rate : DEFSRATE);
    }

    //  Fills the output variable with the information for a person with a salary
    public String toString(){
        String outputStr = "";

        outputStr += "Salaried Payroll Object:";
        outputStr += "\nEmployee Name:\t\t\t\t" + getFirstName() +
                " " + getLastName();
        outputStr += "\nSOC Sec Num:\t\t\t\t" + getSsn();
        outputStr += "\nWeekly Rate:\t\t" + getRate();
        outputStr += "\nYour Earnings:\t\t" + earnings();

        return outputStr;
    }

    //  Gets and returns the earnings for a person with a salary
    @Override
    public double earnings() {
        return getRate();
    }
}
