public class MissingNopException extends Exception implements IPayroll {
    public MissingNopException(){
        super("No Pieceworker Number Of Pieces Provided!");
    }
}
