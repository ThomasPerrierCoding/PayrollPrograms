import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class PayrollDriver06 {

   /* //  Variables
    private static DecimalFormat pattern1 = new DecimalFormat("$###,###,##0.00");
    private static DecimalFormat pattern2 = new DecimalFormat("###,###,##0.00");
    */

    // Main method used to print out all the information for: Hourly, Commission, Salaried, and Pieceworker
    public static void main(String[] args) {
        //  Hourly Default Values
        Hourly06 hourly1 = new Hourly06();
        System.out.println(hourly1 + "\n");

        //  Hourly Filled Values
        Hourly06 hourly2 = new Hourly06("Jack", "Thomas", "123-45-6789", 50, 10);
        System.out.println(hourly2);

        //  Commission Default Values
        Commission06 comm1 = new Commission06();
        System.out.println(comm1 + "\n");

        //  Commission Filled Values
        Commission06 comm2 = new Commission06("Jill", "Jones", "222-33-4444", 150000.0, 0.3);
        System.out.println(comm2);

        //  Salaried Default Values
        Salaried06 sal1 = new Salaried06();
        System.out.println(sal1 + "\n");

        //  Salaried Filled Values
        Salaried06 sal2 = new Salaried06("Mark", "Frederics", "333-22-4444", 2345.99);
        System.out.println(sal2);

        //  Pieceworker Default Values
        Pieceworker06 pw1 = new Pieceworker06();
        System.out.println(pw1 + "\n");

        //  Pieceworker Filled Values
        Pieceworker06 pw2 = new Pieceworker06("Mary", "James", "9876-54-321", 50, 0.75);
        System.out.println(pw2);
    }
}
