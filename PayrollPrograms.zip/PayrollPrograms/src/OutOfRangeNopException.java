public class OutOfRangeNopException extends Exception implements IPayroll {
    public OutOfRangeNopException(){
        super("Pieceworker Number Of Pieces Must Be Between " + MINNOP + " and " + MAXNOP);
    }
}
