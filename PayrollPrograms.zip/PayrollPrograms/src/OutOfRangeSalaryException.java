public class OutOfRangeSalaryException extends Exception implements IPayroll {
    public OutOfRangeSalaryException(){
        super("Salary Must Be Between " + MINSRATE + " and " + MAXSRATE);
    }
}
