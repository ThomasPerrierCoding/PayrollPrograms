import javax.swing.JOptionPane;
import java.text.DecimalFormat;

public class Payroll05
{
    private static final double MAXNONOT = 40.0;
    private static final double OTRATE = 40.0;
    private static final byte MINAGE = 18;
    private static final byte MAXAGE = 75;
    private static final double MINHOURS = 0.0;
    private static final double MAXHOURS = 84.0;
    private static final double MINRATE = 0.0;
    private static final double MAXRATE = 100.0;

    private static DecimalFormat pattern1 = new DecimalFormat("$###,###,##0.00");
    private static DecimalFormat pattern2 = new DecimalFormat("###,###,##0.00");
    private String firstName;
    private String lastName;
    private double hours;
    private double rate;
    private double gross;

    public Payroll05()
    {
        firstName = "FNU";
        lastName = "LNU";
        hours = 0.0;
        rate = 0.0;
    }

}
