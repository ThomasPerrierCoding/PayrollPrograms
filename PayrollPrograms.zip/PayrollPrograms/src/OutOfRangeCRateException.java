public class OutOfRangeCRateException extends Exception implements IPayroll {
    public OutOfRangeCRateException(){
        super("Commission Rate Must Be Between " + MINCRATE + " and " + MAXCRATE);
    }
}
