public class MissingHourlyRateException extends Exception {
    public MissingHourlyRateException(){
        super("No Hourly Rate Provided!");
    }
}
