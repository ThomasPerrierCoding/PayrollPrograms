public class MissingCRateException extends Exception implements IPayroll {
    public MissingCRateException(){
        super("No Commission Rate Provided!");
    }
}
