public class MissingSsnException extends Exception {
    public MissingSsnException(){
        super("No Social Security Number Provided!");
    }
}
