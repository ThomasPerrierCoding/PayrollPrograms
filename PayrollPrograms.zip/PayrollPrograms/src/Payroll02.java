import java.util.Scanner;

public class Payroll02
{
    public static void main(String[] args)
    {
        Scanner userInput = new Scanner(System.in);
        String empFirstName = "";
        String empMi = "";
        String empLastName="";
        String empNumber="";
        byte empAge=0;
        boolean empIsUnion=false;
        double empHoursWorked=0.0;
        double empHourlyRate=0.0;
        double empGrossPay=0.0;

        System.out.print("Please enter the First Name: ");
        empFirstName=userInput.nextLine();

        System.out.print("Please enter the Middle Initial: ");
        empMi=userInput.nextLine();

        System.out.print("Please enter the Last Name: ");
        empLastName=userInput.nextLine();

        System.out.print("Please enter the Age: ");
        empAge=userInput.nextByte();

        System.out.print("Please enter the Union Status: ");
        empIsUnion=userInput.nextBoolean();

        System.out.print("Please enter the Employee Number: ");
        empNumber=userInput.nextLine();

        System.out.print("Please enter the Hours Worked: ");
        empHoursWorked=userInput.nextDouble();

        System.out.print("Please enter the Hourly Pay: ");
        empHourlyRate=userInput.nextDouble();


        empGrossPay = empHoursWorked * empHourlyRate;

        //for (int i = 0; i < 50; ++i) System.out.println();


        System.out.println("Emp First Name: " +empFirstName);
        System.out.println("Emp Middle Init : " +empMi+".");
        System.out.println("Emp  Last Name: " +empLastName);
        System.out.println("Emp Age : " +empAge);
        System.out.println("Emp  Union Status: " +empIsUnion);
        System.out.println("Emp Number : " +empNumber);
        System.out.println("Emp Hours Worked : " +empHoursWorked);
        System.out.println("Emp  Hourly Rate: " +empHourlyRate);
        System.out.println("Emp Gross Pay : " +empGrossPay);
    }
}
