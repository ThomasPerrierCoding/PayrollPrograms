public class OutOfRangeSalesException extends Exception implements IPayroll {
    public OutOfRangeSalesException(){
        super("Sales Must Be Between " + MINSALES + " and " + MAXSALES);
    }
}
