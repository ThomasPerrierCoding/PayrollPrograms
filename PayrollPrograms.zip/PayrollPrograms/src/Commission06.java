public class Commission06 extends Payroll06
                                                  implements IPayroll { // Implements the constants located within the IPayroll interface and extends the information found in the Payroll06 Class
    //  Variables
    private double sales;   // $ amount of sales
    private double rate;    // commission rate

    //  No-Arg Constructor
    public Commission06()
    {
        super();
        this.sales = DEFSALES;
        this.rate = DEFCRATE;
    }

    //  Full-Arg Constructor
    public Commission06(String fn, String ln, String ssn, double s, double r){
        super(fn, ln, ssn);
        setSales(s);
        setRate(r);
    }

    // Getter for the sales variable
    public double getSales() {
        return sales;
    }
    // Setter for the sales variable
    public void setSales(double s) {
        this.sales = ((s >= MINSALES) && (s <= MAXSALES)
                                 ? s : DEFSALES);;
    }

    // Getter for the rate variable
    public double getRate() {
        return rate;
    }
    // Setter for the rate variable
    public void setRate(double r) {
        this.rate = ((r >= MINCRATE) && (r <= MAXCRATE)
                                ? r : DEFCRATE);;
    }

    //  Fills the output variable with the information for a person who does commissions
    public String toString(){
        String outputStr = "";

        outputStr += "Commission Payroll Object:";
        outputStr += "\nEmployee Name:\t\t\t\t" + getFirstName() +
                " " + getLastName();
        outputStr += "\nSOC Sec Num:\t\t\t\t" + getSsn();
        outputStr += "\nCommission Sales:\t\t" + getSales();
        outputStr += "\nCommission Rate:\t\t" + getRate();
        outputStr += "\nEarnings:\t\t" + earnings();

        return outputStr;
    }

    //  Gets and returns the earnings for a person who does commissions
    @Override
    public double earnings() {
        return getSales() * getRate();
    }
}
