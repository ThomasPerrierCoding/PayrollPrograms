public class Hourly06 extends Payroll06
                                        implements IPayroll{ // Implements the constants located within the IPayroll interface and extends the information found in the Payroll06 Class
    //  Variables
    private double hoursWorked;     //  # of hours worked
    private double hourlyRate;      //  $ earned per hour worked

    //  No-Arg Constructor
    public Hourly06(){
        super();
        this.hoursWorked = DEFHOURS;
        this.hourlyRate = DEFRATE;
    }

    //  Full-Arg Constructor
    public Hourly06(String fn, String ln, String ssn, double hw, double hr)
    {
        super(fn, ln, ssn);
        setHoursWorked(hw);
        setHourlyRate(hr);
    }

    // Getter for the hoursWorked variable
    public double getHoursWorked() {
        return hoursWorked;
    }
    // Setter for the hoursWorked variable
    public void setHoursWorked(double hw) {
        this.hoursWorked = ((hw >= MINHOURS) && (hw <= MAXHOURS)
                                                ? hw : DEFHOURS );
    }

    // Getter for the hourlyRate variable
    public double getHourlyRate() {
        return hourlyRate;
    }
    // Setter for the hourlyRate variable
    public void setHourlyRate(double hr) {
        this.hourlyRate = ((hr >= MINRATE) && (hr <= MAXRATE)
                                            ? hr : DEFRATE);
    }

    //  Fills the output variable with the information for a person with a hourly pay
    public String toString(){
        String outputStr = "";

        outputStr += "Hourly Payroll Object:";
        outputStr += "\nEmployee Name:\t\t\t\t" + getFirstName() +
                " " + getLastName();
        outputStr += "\nSOC Sec Num:\t\t\t\t" + getSsn();
        outputStr += "\nHours Worked:\t\t" + getHoursWorked();
        outputStr += "\nHourly Rate:\t\t" + getHourlyRate();
        outputStr += "\nEarnings:\t\t" + earnings();

        return outputStr;
    }

    //  Gets and returns the earnings for a person with a hourly pay
    @Override
    public double earnings() {
        if (getHoursWorked() <= MAXNONOT)   // No Overtime worked
        {
            return getHoursWorked() * getHourlyRate();
        }
        else    // Some Overtime worked
        {
            return ((getHoursWorked() * MAXNONOT) + (getHourlyRate() - MAXNONOT) * getHourlyRate() * OTRATE);
        }
    }
}
