public class MissingFirstNameException extends Exception {
    public MissingFirstNameException(){
        super("No First Name Provided!");
    }
}
