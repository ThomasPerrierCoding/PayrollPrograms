public class OutOfRangeHoursWorkedException extends Exception implements IPayroll {
    public OutOfRangeHoursWorkedException(){
        super("Hours Worked Must Be Between " + MINHOURS + " and " + MAXHOURS);
    }
}
