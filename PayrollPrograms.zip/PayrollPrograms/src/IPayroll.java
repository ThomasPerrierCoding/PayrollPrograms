/*
Interfaces is where you generally, put your constants for a program
*/
public interface IPayroll
{
    //      Miscellaneous Constants
    static String DEFFIRSTNAME = "FNU";
    static String DEFLASTNAME = "LNU";
    static String DEFSSN = "SSNU";

    //      Hourly Constants
    static double MAXNONOT =     40;
    static double OTRATE =      1.5;
    static  double MINHOURS =    0.0;
    static double MAXHOURS =    84.0;
    static double DEFHOURS =    40.0;
    static double MINRATE =     0.0;
    static double MAXRATE =     250.0;
    static double DEFRATE =     25.0;

    //      Commission Constants
    static double MINSALES =    0.0;
    static double MAXSALES =    1000000.0;
    static double DEFSALES =    10000.0;
    static double MINCRATE =    0.1;
    static double MAXCRATE =    0.33;
    static double DEFCRATE =    0.25;

    //      Salaried Constants
    static double MINSRATE =    1000.0;
    static double MAXSRATE =   10000.0;
    static double DEFSRATE =     2500.0;

    //      Pieceworker Constants
    static int MINNOP =      0;
    static int MAXNOP =     1000;
    static int DEFNOP =      100;
    static double MINPPP =      0.1;
    static double MAXPPP =     1.00;
    static double DEFPPP =      0.25;

}
