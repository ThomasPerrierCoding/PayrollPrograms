public class OutOfRangeHourlyRateException extends Exception implements IPayroll {
    public OutOfRangeHourlyRateException(){
        super("Hourly Rate Must Be Between " + MINRATE+ " and " + MAXRATE);
    }
}
